!window.jQuery && document.write(unescape('%3Cscript src="http://ajax.aspnetcdn.com/ajax/jquery/jquery-1.10.2.min.js"%3E%3C/script%3E')); 

!function(e,t,r){function n(){for(;d[0]&&"loaded"==d[0][f];)c=d.shift(),c[o]=!i.parentNode.insertBefore(c,i)}for(var s,a,c,d=[],i=e.scripts[0],o="onreadystatechange",f="readyState";s=r.shift();)a=e.createElement(t),"async"in i?(a.async=!1,e.body.appendChild(a)):i[f]?(d.push(a),a[o]=n):e.write("<"+t+' src="'+s+'" defer></'+t+">"),a.src=s}(document,"script",[resource_url+'Scripts/helpers.min.js'])

if(Page=='home'){}


if(Page=='details'){
!function(e,t,r){function n(){for(;d[0]&&"loaded"==d[0][f];)c=d.shift(),c[o]=!i.parentNode.insertBefore(c,i)}for(var s,a,c,d=[],i=e.scripts[0],o="onreadystatechange",f="readyState";s=r.shift();)a=e.createElement(t),"async"in i?(a.async=!1,e.body.appendChild(a)):i[f]?(d.push(a),a[o]=n):e.write("<"+t+' src="'+s+'" defer></'+t+">"),a.src=s}(document,"script",[resource_url+'zoom/magiczoomplus.js'])
}

$(window).load(function(e) {
$('.pop').fancybox({smallBtn:true,toolbar:false,iframe:{css:{width:'400'}}}); 
$('.pop1').fancybox({smallBtn:true,toolbar:false,iframe:{css:{width:'450'}}}); 
$('.pop2').fancybox({smallBtn:true,toolbar:false,iframe:{css:{width:'600'}}}); 
$('.pop3').fancybox({smallBtn:true,toolbar:false,iframe:{css:{width:'900'}}}); 
 
$('.showhide').click(function(){$('.subdd').hide('fast'); $(this).next().slideToggle('fast');});
setTimeout(function(){$('.dg_opner').fancybox({iframe:{css:{width:'400'}}}).trigger('click')}, 1000);

$('.shownext').click(function(e){var DG=$(this).data('closed');$(DG).hide();$('.subdd').hide('fast');$(this).next().slideToggle('fast');$('.nav-collapse.collapse.show,.dropdown-menu.show').removeClass('show');e.stopPropagation();})

$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});

$('.dd_next').click(function(){$(this).next().slideToggle('fast');$(this).toggleClass('dd_next_act');})

$('.pro_fav').click(function(){$(this).toggleClass('pro_fav_act')})

$('.act_tag a').click(function(){$('.act_tag a').removeClass('act');$(this).addClass('act');
return false;})

$(document).on('click','.rm_link',function(){
$(this).prev().toggleClass('t_text_1_auto');$(this).toggleClass('rm_link_x');
return false;
})

$(".scroll").click(function(event){
event.preventDefault();
$('html,body').animate({scrollTop:$(this.hash).offset().top-55}, 1000);
});

if(Page=='home'){
$("#owl-brands").owlCarousel({autoplay:true,dots:false,nav:true,navText: [ '', '' ],items:4,responsive:{0:{items:3},479:{items:4},767:{items:4},991:{items:3},1151:{items:4},1279:{items:4}}});
$("#owl-missed").owlCarousel({autoplay:true,dots:true,loop:0,items:4,responsive:{0:{items:2},479:{items:3},767:{items:3},991:{items:4},1151:{items:4},1279:{items:4}}});
$("#owl-newly").owlCarousel({autoplay:true,dots:false,nav:true,navText: [ '', '' ],items:4,responsive:{0:{items:2},479:{items:3},767:{items:3},991:{items:3},1151:{items:3},1279:{items:3}}});
$("#owl-featured").owlCarousel({autoplay:true,dots:false,nav:true,navText: [ '', '' ],items:4,responsive:{0:{items:2},479:{items:3},767:{items:3},991:{items:4},1151:{items:4},1279:{items:4}}});
$("#owl-testi").owlCarousel({autoplay:true,dots:false,nav:true,navText: [ '', '' ],items:4,responsive:{0:{items:1},479:{items:1},767:{items:1},991:{items:1},1151:{items:2},1279:{items:2}}});
$("#owl-news").owlCarousel({autoplay:true,dots:false,nav:true,navText: [ '', '' ],items:4,responsive:{0:{items:2},479:{items:2},767:{items:2},991:{items:3},1151:{items:3},1279:{items:3}}});
}

if(Page=='details'){}
$("#owl-news").owlCarousel({autoplay:true,dots:true,loop:0,items:4,responsive:{0:{items:1},479:{items:1},767:{items:1},991:{items:1},1151:{items:1},1279:{items:1}}});
$("#owl-product").owlCarousel({autoplay:false,dots:true,loop:0,items:4,responsive:{0:{items:1},479:{items:1},767:{items:1},991:{items:1},1151:{items:1},1279:{items:1}}});
$("#owl-featured").owlCarousel({autoplay:true,dots:false,nav:true,navText: [ '', '' ],items:4,responsive:{0:{items:2},479:{items:3},767:{items:3},991:{items:4},1151:{items:4},1279:{items:4}}});
});