﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'bn', {
	bold: 'বোল্ড',
	italic: 'ইটালিক',
	strike: 'স্ট্রাইক থ্রু',
	subscript: 'অধোলেখ',
	superscript: 'অভিলেখ',
	underline: 'আন্ডারলাইন'
} );
