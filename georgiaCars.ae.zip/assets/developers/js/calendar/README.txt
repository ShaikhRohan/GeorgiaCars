Tips to Use:


Include jquery library file 1.6.2+

Use 

